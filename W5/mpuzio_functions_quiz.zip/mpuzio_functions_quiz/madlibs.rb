def madlibs(properNoun, adjective) 
	puts properNoun + ' is the ' + adjective + ' coder I ever met!'
end

madlibs('Mike', 'bestest')

def func2(integer1)
	if integer1%2 == 0
		puts 'That is even.'
	else 
		puts 'That is odd.'
	end
end



func2(23)
