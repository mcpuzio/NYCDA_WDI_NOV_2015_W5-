function blastoff(integer) {
	for (var i = integer; i > 0; i--) {
		integer[i]
		return i 
	};
	return "blastoff!"
};

blastoff(10);